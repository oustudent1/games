package game;


public interface CalculablePiece extends GamePiece{
	 void increment();
	
	 void decrement();
	
	 int maxValue();
	
	 void maxValue(int maxVal);
}
