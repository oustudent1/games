package game;

import foundation.AbstractStandardObject;

/**
 * @author joe

 */
public abstract class AbstractGamePiece extends AbstractGameEntity implements GamePiece{
	
	public AbstractGamePiece(int val, String lbl){
		super(val,lbl);
	}
	
}
