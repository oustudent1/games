package game;


public abstract class AbstractGridGameMoveInterpreter extends AbstractGameMoveInterpreter implements GridGameMoveInterpreter{


	public AbstractGridGameMoveInterpreter() {
		super();
	}


	public boolean isValidMove(GameMove move) {
		return false;
	}

}
