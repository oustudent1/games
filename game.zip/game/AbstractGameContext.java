package game;

import foundation.AbstractStandardObject;

/**
 * @author joe

 */
public abstract class AbstractGameContext extends AbstractStandardObject implements GameContext{


	public AbstractGameContext() {
		super();

	}


}
