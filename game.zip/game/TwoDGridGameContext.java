package game;


public interface TwoDGridGameContext {
	public void init();
	
		
	public int rowSize();
	
	public int columnSize();
	
	public GameContextCell cell(Coordinate point);
			
	public boolean validRowAndCol(int row, int col);
	
	public boolean rowInBounds(int row);
	
	public boolean colInBounds(int col);


}
