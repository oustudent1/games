package game.battleship;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import game.AbstractBoardGame;
import game.CalculableGamePiece;
import game.CalculablePiece;
import game.Coordinate;
import game.DefaultPlayer;
import game.GameContext;
import game.GamePiece;
import game.Player;
import game.TwoDGridGameContext;



public class BattleshipGame extends AbstractBoardGame{


	private final int  rowSize = 15;
	private final int  columnSize = 15;
	
	private final int myBoard = 0;
	private final int opponentsBoard = 1;
	private Random random = new Random();
	
	
	private  boolean horizontal;
	
	private TwoDGridGameContext[][] boards;

	public static void main(String[] args){

		BattleshipGame game = new BattleshipGame(2);
	
		game.playGame();				
	}
	
	public BattleshipGame(int playerCount){
			super(playerCount);

	}
	
	
	
	public void playGame(){
		super.playGame();
		outln("Game starts");
		promptForMove();
		 
		//while (!quit() && !gameOver()){
			playARound();
		//	if (gameOver()) break;
			displayBoards();
				
			promptForMove();

		//}
		displayBoards();
	
		outln("Game ends");
	}
	
	public void playARound(int attackingPlayer, int playerBeingAttacked){
		/*get coordinate to attack
		 * attack: if cell is occupied, if hit, report hit and update, else miss
		 * update my oppenoents board
		 */
		 
		//Coordinate shotPosition = new Coordinate(genX(), genY()); 
		Coordinate shotPosition = new Coordinate(0,1);
		
		if (isANewHit(playerBeingAttacked, shotPosition)){
			((BattleshipCell)boards[playerBeingAttacked][myBoard].cell(shotPosition)).shipIsHit();
			
			((BattleshipCell)boards[attackingPlayer][opponentsBoard].cell(shotPosition)).shipIsHit();
			
			if ( ((Player)players.get(playerBeingAttacked)).noPiecesRemaining()){
				this.gameOver = true;
			}
		}
		
		
	
	}
	
	public boolean isANewHit(int player, Coordinate position){
		if ( boards[player][myBoard].cell(position).piece() != null){
			return !((BattleshipCell)boards[player][myBoard].cell(position)).isHit();
		}
		else
			return false;
	
	}
	
	public void hitPlayer(int player, Coordinate position){
		
		
	}
	
	public void init(int rows, int cols){
			board = new BattleshipBoard(rows,cols);
	}
	
	public void init(){
		this.init(15,15);
	}
	
	public void setupGameContext(){
		boards = new BattleshipBoard[playerCount][2];
		for (int i = 0; i<playerCount;i++){
			boards[i][myBoard] = new BattleshipBoard(rowSize, columnSize);	// "my board"
			boards[i][opponentsBoard] = new BattleshipBoard(rowSize, columnSize);	// "opponent's board"
		}
	}
	
	public void displayBoards(){
		for (int i = 0; i<playerCount;i++){
			outln("Player " + (i+1));
			board = boards[i][myBoard];
			displayBoard();
			//boards[i][0]. = new BattleshipBoard(ROWWIDTH, COLWIDTH);	// "my board"
			//boards[i][1] = new BattleshipBoard(ROWWIDTH, COLWIDTH);	// "opponent's board"
		}
	}
	
	public  void setupGame(){
		super.setupGame();
		outln("Setup");
		for (int i = 0; i<playerCount;i++){
			placePieces(i);
		}
		displayBoards();
	}
	
	public void createPieces(){
		pieces.add(new CalculableGamePiece(1,0,"PT Boat"));
		pieces.add(new CalculableGamePiece(2,0,"Submarine"));
		pieces.add(new CalculableGamePiece(3,0,"Destroyer"));
		pieces.add(new CalculableGamePiece(4,0,"Battleship"));
		pieces.add(new CalculableGamePiece(5,0,"Aircraft Carrier"));
	}
	
	public void placePieces(int playerNbr){
		// for each piece, check if piece fits at pos and orientation
		// if fits, placePieceOnBoard(piece,startPos,orientation)
		List newPieces = deepCopy(pieces);

		placePieceOnBoardHorizontally((CalculablePiece)newPieces.get(0),new Coordinate(0,0), playerNbr);
		placePieceOnBoardVertically((CalculablePiece)newPieces.get(1),new Coordinate(2,0), playerNbr);
		placePieceOnBoardHorizontally((CalculablePiece)newPieces.get(2),new Coordinate(2,0), playerNbr);
		placePieceOnBoardVertically((CalculablePiece)newPieces.get(3),new Coordinate(4,0), playerNbr);
		placePieceOnBoardHorizontally((CalculablePiece)newPieces.get(4),new Coordinate(6,0), playerNbr);
		
	}

	public void placePieceOnBoardHorizontally(CalculablePiece piece, Coordinate startPos, int player){
		for (int i=0; i< piece.maxValue();i++){
			startPos.incY(1);
			boards[player][myBoard].cell(startPos).piece(piece);
		}
	}
	
	public void placePieceOnBoardVertically(CalculablePiece piece, Coordinate startPos,  int player){
		for (int i=0; i< piece.maxValue();i++){
			startPos.incX(1);
			boards[player][myBoard].cell(startPos).piece(piece);
		}
	}

 	private List deepCopy(List list){
 		List newList = new ArrayList(list.size());
 		
 		for (int i=0; i< list.size(); i++){
 			newList.add( list.get(i) );
 		}
 		return newList;
 	}
 			
	
	
	public void setupPlayers(){
		for (int i = 0; i<playerCount;i++){
			players.add(new DefaultPlayer("Player" + i+1));
		}
	}
	

	public void promptForMove() {
	}

	public GamePiece retrievePiece() {
		return null;
	}


	public void playARound() {
		playARound(0,1); 				// player 1 attacks player 2 
      	playARound(1,0);   				// player 2 attacks player 1 
	}

	public boolean quit() {
		return false;
	}

	public Player winningPlayer() {
		return null;
	}
	
	private int genX(){
    	return random.nextInt(rowSize);
  	}

  	private int genY(){
    	return random.nextInt(columnSize);
  	}

}

