package game.battleship;

import game.Abstract2DGridGameContext;
import game.Coordinate;


public class BattleshipBoard extends Abstract2DGridGameContext{

  private final int offset = 10;
  
  public BattleshipBoard(int rows, int cols){
  		super(rows,cols);
  		cells = new BattleshipCell[rowSize][columnSize];
  		super.init();
  }

	
		
	public void createCells(){
		for (int i = 0; i<cells.length; i++){
			for (int j = 0; j < cells[i].length; j++){
				cells[i][j] = new BattleshipCell();
			}
		}
	}

	
	public BattleshipCell battleshipCell(Coordinate coord){
			return (BattleshipCell)super.cells[coord.x()][coord.y()];
	}
	
	public BattleshipCell battleshipCell(int x, int y){
			return (BattleshipCell)super.cells[x][y];
	}
  

 
}