package game.battleship;

import game.AbstractGameContextCell;




public class BattleshipCell extends AbstractGameContextCell{

    // Statuses:
    //    0 = Empty/Unknown
    //    1 = Hit
    //    2 = Miss



  public boolean isHit(){
    return status == 1;
  }
  
  public void shipIsHit(){
		status = 1;
  }
  
  public void isAMiss(){
  		status = 2;
  }


}