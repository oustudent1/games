package game;

import java.util.List;


public interface GameController {
	
	void startNewGame(int playerCount);
	
	List getPlayerPieces(int playerNbr);
	
	int getScore(int playerNbr);
	
	boolean move(GameMove move);

}
