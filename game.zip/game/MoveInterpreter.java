package game;


public interface MoveInterpreter {
	
	boolean isValidMove(GameMove move);

}
