package game;

public interface Game {


    boolean gameOver();

	boolean quit();

	void setupGame();
	
	
	void playARound();
	 
	Player winningPlayer();
	 
	int playerCount();
	 
	void init();
	
	void setupPlayers();
		
	void setupGameContext();
			
	void createPieces();	
		
	
	
	 
}
