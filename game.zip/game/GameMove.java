package game;

import java.util.List;


public interface GameMove {
	
	List 		pieces();
	
}
