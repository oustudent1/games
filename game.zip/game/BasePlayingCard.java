package game;


public class BasePlayingCard extends AbstractGamePiece implements PlayingCard {

	private final String CLUB 	= "Club";
	private final String DIAMOND 	= "Diamond";
	private final String HEART 	= "Heart";		
	private final String SPADE 	= "Spade";
	

	private boolean faceUp = false;
	
//	public BasePlayingCard() {
//		super();
//	}
	
		
	public BasePlayingCard(int value, String suit){
		super(value, suit);
	}
	
		
	
	public boolean equals(PlayingCard card){
		return ( value == card.value() && label.equals(card.label()) );
	}


	public String suit(){
		return label();
	}
	
	public void suit(String suit){
			label(suit);
	}


	public void turnOver() {
		faceUp = !faceUp;
	}

  
	public String getValueAsString(){
  		String res = " ";
  	
  		switch (value){
	  		case 10: res = "T"; break;
	  		case 11: res = "J"; break;
	  		case 12: res = "Q"; break;
	  		case 13: res = "K"; break;
	  		default: res = Integer.toString(value);
  		}

		return res;
  	}
  	
  	
  public boolean isFaceUp() {
    return faceUp;
  }
  
  public boolean isFaceDown() {
    return !faceUp;
  }

  public void setFaceUp(boolean newFaceUp) {
    faceUp = newFaceUp;
  }

    public String toString(){
  		String s = isFaceUp()?"u ":"d ";
    	return getValueAsString()  + label.substring(0,1)   + ":" + s;
  }

  public void turnover(){
    faceUp = !faceUp;
  }

  public boolean isRed(){
    return (label.equals(HEART) || label.equals(DIAMOND) );
  }

  public boolean isBlack(){
    return !isRed();
  }

  public boolean isClub(){
    return label.equals(CLUB);
  }

  public boolean isDiamond(){
    return label.equals(DIAMOND);
  }
  
  public boolean isHeart(){
    return label.equals(HEART);
  }
  
  public boolean isSpade(){
    return label.equals(SPADE);
  }
  
 
 	public int compareTo(PlayingCard card){
		int	val = 3; // 3 is illegal value... - should be reset w/in block
	
  		if ( value == card.value() )
  			val = 0;
  		else if (value > card.value() )
  			val = 1;
  		else
  			val = -1;
  		return val;
  	}
  
  	public boolean lessThan(PlayingCard card){
  		return value < card.value();
  	}

 	public boolean isOppositeColor(PlayingCard card){
 		return ( (isRed() && card.isBlack()) || (isBlack() && card.isRed()) );
	}


}
