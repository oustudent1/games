package game;

import java.util.Iterator;


public interface Player {
	
	
	public int score();
	
	public void score(int newScore);


	 Iterator pieces();

	 void addPiece(GamePiece piece);
	
	 int piecesRemaining();

	 GamePiece getPiece(String label);
	
	 String piecesAsString();
	 
	 GamePiece retrievePiece();

	 boolean noPiecesRemaining();
}
