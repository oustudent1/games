package game;

import foundation.AbstractStandardObject;


public class AbstractGamePolicy extends AbstractStandardObject {
	

}
