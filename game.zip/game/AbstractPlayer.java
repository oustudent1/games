package game;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import foundation.AbstractStandardObject;

/**
 * @author joe

 */
public abstract class AbstractPlayer extends AbstractStandardObject implements Player{
	

	protected List pieces;
	protected int score;
	private String name;
		
		
	public AbstractPlayer() {
		this("No Name",10);
	}
	
	public AbstractPlayer (String name){
		this(name, 10);
	}
	

		
	public AbstractPlayer(String name, int initPiecesCount){
		super();
		pieces = new ArrayList(initPiecesCount);
		this.name = name;
		
	}

	public int score(){
		return score;
	}
	
	public void score(int newScore){
		score = newScore;
	}


	public Iterator pieces(){
		return pieces.iterator();
	}

	public void addPiece(GamePiece piece){
		pieces.add(piece);
	}
	
	public int piecesRemaining(){
			return pieces.size();
	}
	
	public void swapPiece(GamePiece pieceToSwapOut, GamePiece pieceToSwapIn){
		
		pieces.remove(pieces.indexOf(pieceToSwapOut));
		pieces.add(pieces.indexOf(pieceToSwapOut),pieceToSwapIn);
		
	}

	public GamePiece getPiece(String label){
		GamePiece piece = null;
		
		for (int i = 0; i< pieces.size();i++){
				if ( ((GamePiece)pieces.get(i)).label().equals(label)){
						piece = (GamePiece)pieces.get(i);
						pieces.remove(i);
						return piece;
				}
			}
		return piece;
	}
	
	public String piecesAsString(){
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < pieces.size(); i++)
			sb.append (   ((GamePiece)pieces.get(i)).label()    );
		return sb.toString();
	}
	
			
	public boolean noPiecesRemaining(){
			return pieces.size() == 0;
	}
	
	public GamePiece retrievePiece(){
		return null;
	}


}
