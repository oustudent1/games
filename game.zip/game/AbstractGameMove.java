package game;


public abstract class AbstractGameMove extends AbstractGamePolicy implements GameMove{

	
	public AbstractGameMove() {
		super();
	}


}
