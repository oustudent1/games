package game.blackjack;

// Copyright (c) 2000 odk


public class Card extends Object {
  private int suit;
  private int value;
  private boolean faceUp;

  /**
   * Constructor
   */
  public Card() {
    this(4,0);
  }

  public Card(String suit, int value) {
   super();
   setSuit(makeIntSuit(suit));
   setValue(value);
   setFaceUp(false);
  }

  public Card(int suit, int value) {
    super();
    setSuit(suit);
    setValue(value);
    setFaceUp(false);
  }

  public String getSuit() {
    switch (suit){
    case 0 : return "Clubs";
    case 1 : return "Diamonds";
    case 2 : return "Hearts";
    case 3 : return "Spades";
    case 4 : return "JOKER";
    }
    return null;
  }

  public void setSuit(int newSuit) {
    suit = newSuit;
  }

  private int makeIntSuit(String newSuit) {
    if(newSuit.equals("Clubs")) return 0;
    if(newSuit.equals("Diamonds")) return 1;
    if(newSuit.equals("Hearts")) return 2;
    if(newSuit.equals("Spades")) return 3;
    if(newSuit.equals("JOKER")) return 4;
    return -1;
    }

  private String getFormattedSuit(){
    switch (suit){
    case 0 : return "C";
    case 1 : return "D";
    case 2 : return "H";
    case 3 : return "S";
    case 4 : return "J";
    }
    return null;

  }

  public int getValue() {
    return value;
  }

  public void setValue(int newValue) {
    value = newValue;
  }

  private String getValueAsString(){
  	String res = " ";

  	switch (value){
  		case 10: res = "T"; break;
  		case 11: res = "J"; break;
  		case 12: res = "Q"; break;
  		case 13: res = "K"; break;
  		default: res = Integer.toString(value);
  	}

	return res;
  	}

  public boolean isFaceUp() {
    return faceUp;
  }

  public boolean isFaceDown() {
    return !faceUp;
  }

  public void setFaceUp(boolean newFaceUp) {
    faceUp = newFaceUp;
  }
 /* public String toString(){
  String s = isFaceUp()?"t ":"f ";
    return getValueAsString() + " of " + getFormattedSuit()   + ":" + s;
  }
*/
    public String toString(){
  String s = isFaceUp()?"u ":"d ";
    return getValueAsString()  + getFormattedSuit()   + ":" + s;
  }

  public void turnover(){
    faceUp = !faceUp;
  }

  public boolean isRed(){
    return (suit == 1 || suit == 2);
  }

  public boolean isBlack(){
    return !isRed();
  }

  public boolean isClub(){
    return suit == 0;
  }

  public boolean isDiamond(){
    return suit == 1;
  }

  public boolean isHeart(){
    return suit == 2;
  }

  public boolean isSpade(){
    return suit == 3;
  }

  public boolean equals(Card c){
  	 return ( (this.getValue() == c.getValue() ) && (this.getSuit().equals(c.getSuit()) ) );
  }

  public int compareTo(Card c){
	int	val = 3; // 3 is illegal value... - should be reset w/in block

  	if ( this.getValue() == c.getValue() )
  		val = 0;
  	else if (this.getValue() > c.getValue() )
  		val = 1;
  		else
  			val = -1;
  	return val;
  }

  public boolean lessThan(Card c){
  	return this.getValue() < c.getValue();
  }

 public boolean isOppositeColor(Card c){
 	return ( (this.isRed() && c.isBlack()) || (this.isBlack() && c.isRed()) );
}



}