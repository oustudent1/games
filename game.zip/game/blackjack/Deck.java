package game.blackjack;

// Copyright (c) 2000 odk
import game.BlackJack.*;
import java.util.*;

public class Deck extends Object {

  private final int MAXCARDS;
  private Card[] baseDeck = null;
  private Card[] dealDeck = null;
  private int current;


  /**
   * Constructor
    */
  public Deck() {
    this(52);
  }

  public Deck(int numCards) {
    super();
    MAXCARDS = numCards;
    baseDeck = new Card[MAXCARDS];
    dealDeck = new Card[MAXCARDS];
    for (int i = 0; i < MAXCARDS;i++)
      dealDeck[i] = null;

    setupDeck();
  }

  public void shuffle() {


/* keep two decks - dealdeck contains card objects in random order
 * randomly assign the card from the basedeck (in suit-value order) to deal deck
 * */
    Random random = new Random();
    boolean done = false;
    int cardnum = -1;
    current = 0;


    System.out.println("Start shuffle");
    cardnum = random.nextInt(52);


    while (! done){

      if (dealDeck[cardnum] == null){ // thanks to Barbara for this alogrithm!
        dealDeck[cardnum] = baseDeck[current++];
        done = current > MAXCARDS -1;
      }
      cardnum = random.nextInt(52);
    }//end while
    current = -1;
    System.out.println("End shuffle");
  }

  public Card deal() {

    // deal next card
    if (current < MAXCARDS -1) {
      current ++;
    }
    return dealDeck[current];
  }

  public int cardsRemaining() {

    return MAXCARDS-1 - current;
  }

  public boolean moreCards() {

    return current < MAXCARDS -1;
  }

  public void setupDeck(){
    // build base deck
    for (int suit = 0; suit<4; suit++){
      for (int val = 0; val < 13; val ++){
        baseDeck[(suit * 13) + val] = new Card(suit,val+1);
      //  if (baseDeck[(s * 13) + v] == null) System.out.println("***************   " +s +"-"+ v + " --" +( ((s) * 13) + v));
        //System.out.println(s +"-"+ v + " --" +( ((s) * 13) + v));
      }
    }
  }
}