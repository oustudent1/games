package game.blackjack;

import java.util.Iterator;
import java.util.List;

import game.AbstractCardGame;
import game.Player;


public class BlackJackGame extends AbstractCardGame {

	private final String DEALER = "Dealer";


	public BlackJackGame() {
		super();
	}

	public BlackJackGame(int playerCount) {
		super(playerCount);
	}


	public static void main(String[] args){

		BlackJackGame game = new BlackJackGame();

		game.playGame();
	}

	public void playGame(){
		super.playGame();
		displayHands();
		while(!gameOver() && !quit()){
			playARound();
			displayHands();
		}
	}

	protected void init(){}

	public void setupGame(){
		super.setupGame();

	}

	public void setupPlayers(){
		players.add(new BlackJackPlayer(DEALER,0)); // dealer
		players.add(new BlackJackPlayer("Joe", 1000));
	}

	public void setupGameContext(){

	}

	public void createPieces(){
		createDeck();
	}

	public void createDeck() {
	}



	public void playARound(){
		BlackJackPlayer currentPlayer = null;

		dealAHand(players);
		Iterator thePlayers = players.iterator();
		while (thePlayers.hasNext()){
			currentPlayer = (BlackJackPlayer)thePlayers.next();
			currentPlayer.placeBet(100);
			//currentPlayer.playCards();
		}
	}


	private void displayHands(){
		// for each player - get their cards and display cards, money left and
	}
	public void dealAHand(List players){
		// for each player, deal the correct number of initiala cards

	}





}
