package game.blackjack;

import game.AbstractPlayer;



public class BlackJackPlayer extends AbstractPlayer {

	private int totalMonies = 0;
	private int lastBet = 0;


	public BlackJackPlayer(String name, int initialMoney){
		super(name);
		score = initialMoney;
	}


	public void placeBet(int amount){
	//	if (amount > totalMonies) throw
		totalMonies -= amount;
	}

	public void win(int amount){
		totalMonies += amount;
	}



}
