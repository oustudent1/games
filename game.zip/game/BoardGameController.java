package game;


public interface BoardGameController extends GameController {
	
	Object[][] getBoardValues();

}
