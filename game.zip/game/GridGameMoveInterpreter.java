package game;


public interface GridGameMoveInterpreter extends MoveInterpreter {


		boolean isValidCoordinate(Coordinate coord);
		boolean isValidPiecesCount(int pieceCount);
}
