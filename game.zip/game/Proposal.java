package game;

public interface Proposal {

	String description();
	
	float value();
	
	
}
