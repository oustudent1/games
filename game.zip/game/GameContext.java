package game;


public interface GameContext {

}
