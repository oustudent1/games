package game;


public abstract class AbstractGamePlay extends AbstractGamePolicy {

}
