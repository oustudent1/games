package game.ui.grid.context;

import foundation.AbstractStandardObject;


public abstract class AbstractGridGameContextRenderer extends AbstractStandardObject implements GridContextRenderer{
	
	private int rowSize;
	private int columnSize;

	public AbstractGridGameContextRenderer(int rows, int cols) {
		rowSize = rows;
		columnSize = cols;
	}

}
