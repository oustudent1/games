package game.ui.grid.context;


public class DefaultGridContextRenderer
	extends AbstractGridGameContextRenderer {


	public DefaultGridContextRenderer(int rows, int cols) {
		super(rows, cols);
	}
	
	public String getPlayerRequest(){
		return null;
	}

}
