package game.ui.grid.context;
import game.BoardGameController;
import game.ui.GameApplication;
import game.ui.ScrabbleApplication;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EtchedBorder;

public class ScrabbleFrame extends JFrame {


  private BoardGameController theGame = new ScrabbleApplication();

  //private Vector columnId

	private Object[][] values; 
  	private String[] colNames = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n", "o"};
  	
  	String request;

  	private DefaultTableModel tableModel;
  	private JTable boardTbl;
 	private JScrollPane jScrollPane1;
  	private JPanel jPanel1 = new JPanel();
  	private JLabel jLabel1 = new JLabel();
  	private JTextField playerTf = new JTextField();
  	private JLabel jLabel2 = new JLabel();
  	private JTextField moveTf = new JTextField();
  	private JLabel statusLbl = new JLabel();
  	private JButton playBtn = new JButton();
  private JButton newGameBtn = new JButton();
  private JPanel jPanel2 = new JPanel();
	
  			

  public ScrabbleFrame()
  {
    try
    {
      jbInit();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

  }

  private void jbInit() throws Exception
  {

	startNewGame();

  

  
    this.getContentPane().setLayout(null);
    this.setSize(new Dimension(668, 668));
    this.setTitle("Scrabble ");
    jScrollPane1.setBounds(new Rectangle(10, 10, 640, 485));
    jPanel1.setBounds(new Rectangle(10, 505, 640, 125));
    jPanel1.setBorder(BorderFactory.createLineBorder(new Color(46, 56, 177), 1));
    jPanel1.setLayout(null);
    jLabel1.setText("Player:");
    jLabel1.setBounds(new Rectangle(10, 15, 65, 15));
    playerTf.setBounds(new Rectangle(60, 10, 59, 20));
    playerTf.setEditable(false);
    jLabel2.setText("Move:");
    jLabel2.setBounds(new Rectangle(10, 50, 34, 16));
    moveTf.setBounds(new Rectangle(60, 50, 115, 20));
    statusLbl.setText("Games Status");
    statusLbl.setBounds(new Rectangle(5, 5, 600, 15));
    statusLbl.setForeground(new Color(93, 74, 228));
    statusLbl.setFont(new Font("Dialog", 1, 12));
    playBtn.setText("Play");
    playBtn.setBounds(new Rectangle(185, 50, 65, 20));
    playBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          playBtn_actionPerformed(e);
        }
      });
    newGameBtn.setText("Start New Game");
    newGameBtn.setBounds(new Rectangle(495, 20, 130, 60));
    newGameBtn.setFont(new Font("Dialog", 1, 11));
    newGameBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          newGameBtn_actionPerformed(e);
        }
      });
    jPanel2.setBounds(new Rectangle(5, 95, 625, 25));
    jPanel2.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
    jPanel2.setLayout(null);
    jPanel2.add(statusLbl, null);
    jPanel1.add(jPanel2, null);
    jPanel1.add(newGameBtn, null);
    jPanel1.add(playBtn, null);
    jPanel1.add(moveTf, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(playerTf, null);
    jPanel1.add(jLabel1, null);
    this.getContentPane().add(jPanel1, null);
   // jScrollPane1.getViewport().add(boardTbl, null);
   this.getContentPane().add(jScrollPane1, null);

  }

  private void setupTable(){
// gets 2d grid context info from game and buiuld the table model based on row and col size
   	
   	values = theGame.getGameValues();
  	tableModel = new DefaultTableModel(values, colNames);
  	boardTbl = new JTable(tableModel);
  	jScrollPane1 = new JScrollPane(boardTbl);
  
     values = theGame.getGameValues();

    boardTbl = new JTable(values, colNames);

  }

  private void playBtn_actionPerformed(ActionEvent e) {
  	request = moveTf.getText();
  	if (theGame.interpretRequest(request)) 
  		theGame.playARound(0);
  //	updateDisplay();
  }
  
  private void updateDisplay(){
  	
  }
  
  private void startNewGame(){
  	    theGame.startNewGame();
   		setupTable();
  }
  	

  private void newGameBtn_actionPerformed(ActionEvent e) {
  	startNewGame();
  }
  		
}