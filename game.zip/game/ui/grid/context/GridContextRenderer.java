package game.ui.grid.context;

import game.ui.ContextRenderer;


public interface GridContextRenderer extends ContextRenderer {

}
