package game.ui;


public interface ContextRenderer {
	
	String getPlayerRequest();

}
