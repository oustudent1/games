package game.ui;

import foundation.AbstractStandardObject;
import game.Game;
import game.GameController;
import game.GameMove;
import java.util.List;


public class AbstractGameController extends AbstractStandardObject implements GameController{


	private Game theGame;

	public AbstractGameController() {
		super();
	}
	

	public List getPlayerPieces(int playerNbr) {
		return null;
	}

	public int getScore(int playerNbr) {
		return 0;
	}

	public boolean move(GameMove move) {
		return false;
	}


	public void startNewGame(int playerCount) {
		theGame.setupGame();
	}

}
