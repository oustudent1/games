package game.ui;

import foundation.AbstractStandardObject;
import game.BoardGame;
import game.Coordinate;
import game.DefaultGridGameMove;
import game.GameMove;
import game.GridGameMove;
import game.GridGameMoveInterpreter;
import game.scrabble.ScrabbleGame;
import game.scrabble.ScrabbleMoveInterpreter;
import game.ui.grid.context.DefaultGridContextRenderer;
import game.ui.grid.context.GridContextRenderer;

import java.util.StringTokenizer;

import com.ffic.kernel.StringOp;


public class ScrabbleApplication extends AbstractGameApplication{

		private static GridGameMoveInterpreter moveInterpreter;
		private static GridGameMove move ;
		private String playerRequest ="";
		private BoardGame game = new ScrabbleGame();
		
		StringTokenizer st;

		
		private Coordinate newWordCoordinate;
		private boolean horizontal = false;
		private String word;
		
		//GridContextRenderer gameView = new DefaultGridContextRenderer(game.rowSize(), game.columnSize());
		
		public void startNewGame(){
			game.setupGame();
		}
		
		public Object[][] getGameValues(){
			return game.getGameContextCellValues();
		}
	

	
	public void playARound(int playerNbr){
		
	}
	
	public boolean interpretRequest(int playerNbr, String theMove){
		
		st = new StringTokenizer(theMove.substring(0,theMove.length()-1),",");
		String str;
			
		while (st.hasMoreTokens()){

				try {
					int x = Integer.parseInt(st.nextToken());
					int y = Integer.parseInt(st.nextToken());
					newWordCoordinate = new Coordinate(x,y);
					horizontal = st.nextToken().toUpperCase().equals("H")?true:false;
					str = st.nextToken();
					if ( ! StringOp.isEmpty(str)) word = str;
				} 
				catch (Exception e) {  
					return false;
				}
		}
		
		return true;
		
		
	}
	


	
	private static void displayResults(GridContextRenderer view){
		
	}
	
	private static boolean isQuitGame(String move){

		if (move == null) return false;
		if (move.length() > 1) return false;
		if (move.toUpperCase().substring(0,1).equals("Q")) return true;
		else return false;
	}


}
