package game;


public class DefaultPlayer extends AbstractPlayer {
	
	public DefaultPlayer(String name){
		super(name);
	}

}
