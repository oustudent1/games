package game;

import foundation.AbstractStandardObject;
import java.util.ArrayList;
import java.util.List;


public abstract class AbstractGame extends AbstractStandardObject implements Game{

	protected List players = new ArrayList();
	protected boolean gameOver = false;
	protected int playerCount = 0;
	
	
	public AbstractGame() {
		this(2);
	}
	
	public AbstractGame(int playerCnt){
		super();
		playerCount = playerCnt;
	}
		
		
	public  void setupGame(){
		setupGameContext();	
		createPieces();	
		setupPlayers();
	}
	
	public int playerCount(){
		return playerCount;
	}
	
	public  boolean gameOver(){
		return gameOver;
	}
	
	public void playGame(){
		setupGame();
		
	}



}
