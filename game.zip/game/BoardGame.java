package game;


public interface BoardGame {
		
	 void promptForMove();
	 
	 GamePiece retrievePiece();

}
