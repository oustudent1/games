package game;


public interface GridGameMove extends GameMove {
	
	boolean	isNorth();
	boolean 	isSouth();
	boolean	isEast();
	boolean	isWest();
	boolean	isForward();
	boolean	isBackward();
	void 		horizontal(boolean horiz);
	void 		vertical (boolean vert);
	
	void 		position(Coordinate coord);
	Coordinate 	position();
}
