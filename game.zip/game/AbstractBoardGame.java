package game;

import java.util.ArrayList;
import java.util.List;


public abstract class AbstractBoardGame extends AbstractGame implements BoardGame{



	protected TwoDGridGameContext board;
	
	
	protected List pieces = new ArrayList();
	

	public AbstractBoardGame(int playerCount){
		super (playerCount);
	}



	public abstract void promptForMove();


	public abstract GamePiece retrievePiece();
	
		
	public  void displayBoard(){
		Coordinate point = new Coordinate(0,0);
		
		for (int row = 0; row < board.rowSize();row++){
			for (int col = 0; col < board.columnSize();col ++){
				out("|");
				point.x(row);
				point.y(col);
				out(board.cell(point).toString().substring(0,2));
				out("|");
			}
			outln(" ");
		}
		outln(" "); 
		
	}
}
