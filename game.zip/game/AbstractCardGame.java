package game;


public abstract class AbstractCardGame extends AbstractGame implements CardGame{


	private PlayingCard[] deckOfCards; 
	private int currentCard = 0;
	
	
	public AbstractCardGame() {
		super();
	}

	public AbstractCardGame(int playerCount) {
		super(playerCount);
		createDeck();
	}
	
	public abstract void createDeck(); 

	public Player winningPlayer() {
		return null;
	}

	public boolean quit() {
		return false;
	}

	
	public void shuffleDeck(){
		
		
	}
	
	public PlayingCard dealACard(){
		PlayingCard card = null;
		
		if (deckOfCards.length>0){
			card =  deckOfCards[currentCard];
			currentCard++;
		}		
		
		return card;
	}

}
