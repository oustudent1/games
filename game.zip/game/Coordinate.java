package game;

import foundation.AbstractStandardObject;

/**
 * 
 * @author joe

 */
public class Coordinate extends AbstractStandardObject {

	private int x;
	private int y;

	public Coordinate(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int x() {
		return x;
	}

	public int y() {
		return y;
	}

	public void x(int x) {
		this.x = x;
	}

	public void y(int y) {
		this.y = y;
	}

	public void incX(int i){
			x += i;
	}

	public void incY(int i){
			y += i;
	}
}
