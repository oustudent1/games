package game;

import foundation.AbstractStandardObject;

public abstract class AbstractGameEntity extends AbstractStandardObject implements GameEntity {

	protected String label;
	
	protected int value;
	
	
	
	public AbstractGameEntity() {
		this(0,"_");

	}
	
	public AbstractGameEntity(int val, String lbl){
			super();
			init(val, lbl);
	}
	
	
	public String toString(){
			return  label;
	}

	public void value(int val){
		 value = val;
	}

	public int value(){
		return value;
	}

	public void label(String lbl){
		label = lbl;
	}

	public String label(){
		return label;
	}

	protected void init(int val, String lbl) {
			value = val;
			label = lbl;
	}
	
	

	

	

		

	


}
