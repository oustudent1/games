package game;

/**
 * @author joe
 *

 */
public abstract class Abstract2DGridGameContext extends AbstractGameContext implements TwoDGridGameContext{
	
	private static final int ROW_START = 0;
	private static final int COLUMN_START = 0;
	
	protected  int rowSize;
	protected  int columnSize;
	
	protected GameContextCell[][] cells;

	
	public Abstract2DGridGameContext() {
		super();
	}
	
	public Abstract2DGridGameContext(int rows, int cols) {
		super();
		rowSize=rows;
		columnSize = cols;

	}
	
	public void init(){
		createCells();
	}
	
		
	public int rowSize(){
		return cells.length;
	}
	
	public int columnSize(){
		return cells[0].length;
	}
	
	public GameContextCell cell(Coordinate point){
		return cells[point.x()][point.y()];
	}
	
	protected abstract void createCells();
		
	public boolean validRowAndCol(int row, int col){
		return (rowInBounds(row) && colInBounds(col));
	}
	
	public boolean rowInBounds(int row){
		return row >= ROW_START && row < rowSize;
	}
	
	public boolean colInBounds(int col){
		return col >=COLUMN_START && col < columnSize;
	}



}
