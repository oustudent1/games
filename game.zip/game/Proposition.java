package game;


public interface Proposition {

		void makeProposal(Proposal aProposal);
		
		
}
