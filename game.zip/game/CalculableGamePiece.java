package game;


public class CalculableGamePiece extends AbstractGamePiece implements CalculablePiece{
	
	private int maxValue = 0;


	public CalculableGamePiece(int maxVal, int initVal, String lbl) {
		super(initVal, lbl);
		maxValue(maxVal);
	}
	
	public void increment(){
			value++;
	}
	
	public void decrement(){
			value--;
	}
	
	public int maxValue(){
		return maxValue;
	}
	
	public void maxValue(int maxVal){
			maxValue = maxVal;
	}

}
