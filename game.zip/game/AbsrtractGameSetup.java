package game;

import foundation.AbstractStandardObject;


public abstract class AbsrtractGameSetup extends AbstractGamePolicy {

}
