package game;

import java.util.List;


public class DefaultGridGameMove extends AbstractGameMove implements GridGameMove{


	private Coordinate startPosition;
	private List pieces;
	
	private boolean north 		= false;
	private boolean south 		= false;
	private boolean east 			= false;
	private boolean west 			= false;
	private boolean forward 		= false;
	private boolean backward 		= false;
	private boolean horizontal 	= false;
	private boolean vertical 		= false;
	
	
	public DefaultGridGameMove() {
		super();
	}

	public void north(boolean direction){
		north = direction;
	}
	
	public void south(boolean direction){
		south = direction;
	}
	
	public void east(boolean direction){
		east = direction;
	}
	
	public void west(boolean direction){
		west = direction;
	}
	
	public void forward(boolean direction){
		forward = direction;
	}
	
	public void backward(boolean direction){
		backward = direction;
	}
	
	public void horizontal(boolean direction){
		horizontal = direction;
	}
	
	public void vertical(boolean direction){
		vertical = direction;
	}
	
	
	public boolean isNorth(){
		return north;
	}

	public boolean isSouth(){
		return south;
	}
	
	public boolean isEast(){
		return east;
	}
	
	public boolean isWest(){
		return west;
	}	
	
	public boolean isForward(){
		return east;
	}
	
	public boolean isBackward(){
		return west;
	}		
	
	public boolean isHorizontal(){
		return horizontal;
	}
	
	public boolean isVertical(){
		return vertical;
	}
	
	public Coordinate position(){	
		return startPosition;
	}
	
	public void position(Coordinate coord){
		startPosition = coord;
	}
	
	public List pieces(){
		return pieces;
	}
		
	

}
