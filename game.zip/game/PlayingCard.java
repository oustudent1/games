package game;


public interface PlayingCard extends GameEntity{
	
	boolean isFaceUp();
	
	void turnOver();
	
	public boolean isRed();

  	public boolean isBlack();

  	public boolean isClub();

  	public boolean isDiamond();
  
  	public boolean isHeart();
  
  	public boolean isSpade();

}
