package game;

public interface GameContextCell {

	
	 GamePiece piece();
	
	 void piece(GamePiece aPiece);
	
	 boolean isEmpty();
	
}
