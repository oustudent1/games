package game;


public interface GamePiece extends GameEntity{
	
	 String label();
	
	 void label(String lbl);
	
	 int value();
}
