package game;

public interface GameEntity {
	
	public void value(int val);

	public int value();

	public void label(String lbl);

	public String label();

}
