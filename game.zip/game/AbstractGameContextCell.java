package game;

import foundation.AbstractStandardObject;

/**
 * @author joe
 *

 */
public abstract class AbstractGameContextCell extends AbstractStandardObject implements GameContextCell{
	
	protected GamePiece piece;
	protected int status = 0;
	
	public AbstractGameContextCell(){};
	
	public AbstractGameContextCell(GamePiece aPiece){
		piece = aPiece;
	}
	
	public GamePiece piece(){
		return piece;
	}
	
	public void piece(GamePiece aPiece){
		piece = aPiece;
	}
	
	public boolean isEmpty(){
		return piece == null;
	}
	
	public String toString(){
		String pieceString = piece != null ?piece.toString():" ";
		return statusAsString() + pieceString;
	}
	
	
  	public void setStatus(int s){
    	status = s;
  	}
	
  
  	public String statusAsString (){
  		return Integer.toString(status);
  }
  
  public int status(){
  		return status;
  }

}
