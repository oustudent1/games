package game;

import foundation.AbstractStandardObject;


public abstract class AbstractGameMoveInterpreter extends AbstractStandardObject implements MoveInterpreter{


	public AbstractGameMoveInterpreter() {
		super();
	}

}
