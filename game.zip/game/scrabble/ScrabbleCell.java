package game.scrabble;

import game.AbstractGameContextCell;

/**
 * @author joe

 */
public class ScrabbleCell extends AbstractGameContextCell {
	
	private int multiplierValue = 1;	// initially - 1 - - 2 = double, 3 = triple
	private int multiplierType = 1; 	// 1 means no multiplier, 2 means letter 3 means word
	private String[] types = {" "," ", "l", "w"};
	private String[] values = {" ", " ", "d", "t"};
	
	public ScrabbleCell (){}


	public void multiplier(int mValue, int mType ){
		multiplierValue = mValue;
		multiplierType = mType;
	}
	
	public int value(){
			return multiplierValue;
	}
	
	public int type(){
		return multiplierType;
	}
	
	public boolean isWordMultiplier(){	
		return multiplierType == 3;
	}
	
	public boolean isLetterMultiplier(){	
		return multiplierType == 2;
	}
	
	public int letterMultiplier(){	
		return multiplierValue;
	}
	
	public boolean isMultiplier(){
		return multiplierType > 1;
	}
	
	public String toString(){
		StringBuffer sb = new StringBuffer("");
		
		
		if (isEmpty()){
			sb.append(values[multiplierValue]);
			sb.append(types[multiplierType]);
		}
		else{
			 sb.append(super.toString());	
			 sb.append(" ");	
		}

		return  sb.toString();
	}
}