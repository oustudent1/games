package game.scrabble;

/**
 * @author joe
 *

 */
public class ScrabbleSpecs {


private void loadTiles(){
		// put a brand new set of tiles into the bag. Remove any existing tiles
	
	}
}
