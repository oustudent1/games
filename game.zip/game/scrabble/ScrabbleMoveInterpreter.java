package game.scrabble;

import game.AbstractGameMoveInterpreter;
import game.AbstractGridGameMoveInterpreter;
import game.Coordinate;
import game.GameMove;


public class ScrabbleMoveInterpreter extends AbstractGridGameMoveInterpreter {
	
	private int minX;
	private int minY;


	public ScrabbleMoveInterpreter(int x, int y) {
		super();
		minX = x;
		minY = y;
	}
	
	public boolean isValidOrientation(String orient){
		return orient.toUpperCase().equals("H") || orient.toUpperCase().equals("V");
	}
	
	public boolean isValidCoordinate(Coordinate coord){
		return (coord.x() >= minX) && (coord.y() >= minY);

	}
	
	public int minX() {
		return minX;
	}


	public int minY() {
		return minY;
	}


	public void minX(int aminX) {
		minX = minX;
	}


	public void minY(int aminY) {
		minY = aminY;
	}
	
	public boolean isValidMove(GameMove move){
		return true;
	}
	
	public boolean isValidPieceCount(int pieceCount){
		return pieceCount > 0 && pieceCount < 7; // should check scrabble rule class for max letters in a tray
	} 

}