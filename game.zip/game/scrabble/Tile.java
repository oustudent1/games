package game.scrabble;

import game.AbstractGamePiece;

/**
 * @author joe
 *

 */
public class Tile extends AbstractGamePiece {

	public Tile(int val, String lbl){
		super(val,lbl);
	}

}
