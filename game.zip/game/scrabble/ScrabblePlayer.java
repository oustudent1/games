package game.scrabble;

import java.util.ArrayList;
import java.util.List;

import game.AbstractPlayer;
import game.GamePiece;


public class ScrabblePlayer extends AbstractPlayer {


	public ScrabblePlayer() {
		super();
	}
	
	public List getWordAsTiles(String word){
		List tiles = new ArrayList(word.length());
		for (int i = 0; i < word.length();i++){
			GamePiece piece = getPiece(word.substring(i,i+1));
			if (piece !=null){
				tiles.add(piece);
			}
		}
		return tiles;
		
	}

}
