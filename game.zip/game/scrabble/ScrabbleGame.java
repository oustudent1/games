// Joe Greenwald
//


package game.scrabble;

import foundation.BasicIO;
import game.AbstractBoardGame;
import game.Coordinate;
import game.GamePiece;
import game.Player;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;



public class ScrabbleGame extends AbstractBoardGame{
	
	// constants
		private final int  ROWWIDTH = 15;
		private final int  COLWIDTH = 15;
		private final int WORDTYPE = 3;		// 3 is word multiplier
		private final int MAXTRAYLETTERS = 7;
		private final String BLANKTILE = "b";
		
		
		private  ScrabbleBoard board;
		private  ScrabblePlayer player;
		
		private  Hashtable tileValueMap = new Hashtable();
		private  List wordAsTiles;
		
		private  String choice;
		private boolean  validInput = false;
		
		private  String word;
		private  boolean wordFound = false;
		private int wordMultiplier;
								
		private  Coordinate newWordCoord;
		private  int wordRowStart;
		private  int wordColumnStart;
		private  boolean horizontal;
		private  boolean adjacentIsHorizontal;
		

		private boolean gameOver = false;

		
	
	public ScrabbleGame(){
		this(15,15,1);
	}
	
	public ScrabbleGame(int rows, int cols, int playerCount){
		super(playerCount);
		init(rows,cols);
	}
	
	public static void main(String[] args){

		ScrabbleGame game = new ScrabbleGame();
	
		game.playGame();				
	}
	
	
	
	public void playGame(){
		super.playGame();
		outln("Game starts");
		promptForMove();
		 
		while (!quit() && !gameOver()){
			playARound();
			if (gameOver()) break;
			displayBoard();
			displayPlayer();
			
			fillPlayersTray();
			
			promptForMove();

		}
		displayBoard();
		displayPlayer();		
		outln("Game ends");
	}

	
	public void init(int rows, int cols){
			board = new ScrabbleBoard(rows,cols);
	}
	
	public void init(){
		this.init(15,15);
	}
	
	public void setupGameContext(){
		board = new ScrabbleBoard(ROWWIDTH, COLWIDTH);
	}

	
	public  void setupGame(){
		createTileValueMap();
		super.setupGame();
		outln("Setup");

		displayBoard();
		displayPlayer();	
	}
	
	public  void playARound(){

		String newWord = parseMove();
		if (newWord != null){
		
			if (wordFitsOnBoard(newWord)){
				
				wordAsTiles = player.getWordAsTiles(newWord);
				if (wordAsTiles.size() >0){
					addWord(wordAsTiles,newWordCoord, horizontal);
					player.score(player.score() + tallyNewScore(wordAsTiles,newWordCoord, horizontal));
					fillPlayersTray();
					if (player.piecesRemaining()<1) {
						gameOver = true;
						return;
					}
				}
			}
			else 
				outln("Word out of game bounds - not added");
		}
		else 
			outln("Invalid Input - try again");
		
	}
	
	private  String parseMove() {
		StringTokenizer st = new StringTokenizer(choice.substring(0,choice.length()-1),",");
		String result = null;
		
		while (st.hasMoreTokens()){

				try {
					int x = Integer.parseInt(st.nextToken());
					int y = Integer.parseInt(st.nextToken());
					newWordCoord = new Coordinate(x,y);
					horizontal = st.nextToken().toUpperCase().equals("H")?true:false;
					result = st.nextToken();
					if(result.length() <1 || result.length() > 7) result= null;
				} catch (Exception e) {  return null;
				}
		}
		return result;

		
	}
	
	private boolean wordFitsOnBoard(String newWord){
		if(horizontal){
				if ( (board.colInBounds(newWordCoord.x()-1 + newWord.length())) &&  (board.colInBounds(newWordCoord.x()-1 )) ){
					return true;
			}
		}
			else{
				if ( (board.rowInBounds(newWordCoord.y() -1 + newWord.length()))  && (board.rowInBounds(newWordCoord.y() -1 )) ){
					return true;
				}
			}
		return false;
		
	}

	
	public  void promptForMove(){
		boolean badWord = true;
		outln("Enter move (row, column, Horizontal or Vertical, word) or q to quit");
		choice = BasicIO.readString();
	
		while(badWord){
			//outln("Enter move (row, column, Horizontal or Vertical, word) or q to quit");
			//choice = readString();
			if (word != null && word.length() > 0) badWord = false;
		}

		outln(choice);	

		
	}
	
	private void handleBlankTile (Tile aTile){
//		StringBuffer newWord = new StringBuffer("");
//		
//		for (int i = 0; i < inputWord.length(); i++){
//			if (inputWord.charAt(i) == 'b'){
				outln("Enter letter for blank tile");
				
				// replace blank tile with new tile of specified letter.
				
				String ch =  BasicIO.readString().substring(0,1);;
				aTile.label(ch.toUpperCase());
				aTile.value( ((Integer)tileValueMap.get(ch.toUpperCase())).intValue());
				//newWord.append(Character.toUpperCase(ch));
//			}
//			else
//				newWord.append(Character.toUpperCase(inputWord.charAt(i)));
//		}
//		return newWord.toString();
	}

	
	public void addWord(List wordAsTiles, Coordinate newWordCoord, boolean horizontal){
		
			wordMultiplier = 0;	// reset multiplier factor before adding word 
			Tile aTile = null;

		// decrement row/col to adjust for 0 start
		int row = newWordCoord.x()-1;
		
		int col = newWordCoord.y()-1;
		// first, add new tiles to the board
		if(horizontal){
					for (int pos =  col; pos < col + wordAsTiles.size(); pos++){
						aTile = (Tile)wordAsTiles.get(pos-col);
						if (aTile.label().equals(BLANKTILE)) handleBlankTile(aTile);
						((ScrabbleBoard)board).scrabbleCell(row,pos).piece( aTile );
						if (((ScrabbleBoard)board).scrabbleCell(pos,col).type() ==WORDTYPE) wordMultiplier += ((ScrabbleBoard)board).scrabbleCell(pos,col).value();
						}

					adjacentIsHorizontal = !horizontal;

			}
			else{
					for (int pos =  row; pos  < row + wordAsTiles.size(); pos++){
						aTile = (Tile)wordAsTiles.get(pos-row);
						if (aTile.label().equals(BLANKTILE)) handleBlankTile(aTile);
						((ScrabbleBoard)board).scrabbleCell(pos,col).piece( (Tile)wordAsTiles.get(pos-row) );
						if (((ScrabbleBoard)board).scrabbleCell(pos,col).type() ==WORDTYPE) wordMultiplier += ((ScrabbleBoard)board).scrabbleCell(pos,col).value();
					}

					adjacentIsHorizontal = true;
				}
		if (wordMultiplier == 0) wordMultiplier = 1;
		

	}
	
	
	
	public int tallyNewScore(List wordAsTiles, Coordinate newWordCoord, boolean horizontal){

		int score = 0;
		Coordinate wordStart = null;
		int rowInc = 0;
		int colInc = 0;
		if (horizontal)
			colInc++;
		else
			rowInc++;
		Coordinate nextLetterCoord = new Coordinate(newWordCoord.x()-1, newWordCoord.y()-1);
			
		
		// for the first of the new letters, get start of word, and tally the new word
		wordStart = determineStartOfWord(newWordCoord,horizontal);
		if (wordStart!=null){
			if (horizontal){
				score += tallyTileValuesHorizontally(wordStart);
			}
			else
				score += tallyTileValuesVertically(wordStart);
		}
				
		
		
			// for each new letter, get start of word in the cross direction
		Iterator iter = wordAsTiles.iterator();
		
		while ( iter.hasNext()){
			nextLetterCoord.incX(rowInc);
			nextLetterCoord.incY(colInc);
			wordStart = determineStartOfWord(nextLetterCoord,adjacentIsHorizontal);	// get word from cross orienation
			if (wordStart!=null){
				if (horizontal){
					score += tallyTileValuesVertically(wordStart);
				}
				else
					score += tallyTileValuesHorizontally(wordStart);
			}
			iter.next();
		}
		
	return score;
	}
	
	
	private Coordinate determineStartOfWord(Coordinate newWordCoord,boolean horizontal){

		Coordinate wordStart = null;
		int row = newWordCoord.x()-1;
		int col = newWordCoord.y()-1;

		wordFound = false;	// assume word not found
		
		// given the row and column, find the first non-empty & valid cell
		// loop backwards (up for Vert or left for Horiz) and look for edge of board (col or row == 0) 
		//   or first empty cell
		
		if (horizontal){
				for (int wordColStart = col; wordColStart >= 0;wordColStart--){
					 if (!((ScrabbleBoard)board).scrabbleCell(row, wordColStart).isEmpty()){ wordStart = new Coordinate(row, wordColStart); }// do nothing - look for next cell
					 else{
					 	wordColStart ++;
					 	wordStart = new Coordinate(row, wordColStart);
						wordStart.y(wordColStart);	// empty cell - so start was the last one
					 	break;
					 }
					 }
			}
			else {
				for (int wordRowStart = row; wordRowStart >= 0;wordRowStart--){
					 if (!((ScrabbleBoard)board).scrabbleCell(wordRowStart, col).isEmpty()){wordStart = new Coordinate(wordRowStart, col); }// do nothing - look for next cell
					 else{
					 	wordRowStart ++;	// empty cell - so start was the last one
					 	wordStart = new Coordinate(wordRowStart,col);
					 	wordStart.x(wordRowStart);
					 	break;
					 }
					 }
			}
		return wordStart;	
	}
	

	
	private int tallyTileValuesVertically(Coordinate wordStart){
		return tallyTileValues(wordStart, 1,0); // change col values		
	}
	
	private int tallyTileValuesHorizontally(Coordinate wordStart){
		return tallyTileValues(wordStart, 0,1); // change row values
	}
	
	public int tallyTileValues(Coordinate wordStart, int rowOffset, int colOffset){
		
		int row = wordStart.x();
		int col = wordStart.y();
		int letterCount = 0;	// must find at least two letters to count as a word
		int letterMult = 1;
		
		// iterate to end of board or no next cell while tallying count
		int tally = 0;
		ScrabbleCell targetCell =  ((ScrabbleBoard)board).scrabbleCell(wordStart);

		while(!targetCell.isEmpty()){	// loop until blank cell w/ no tile

			if (targetCell.isLetterMultiplier()) {
				letterMult = targetCell.letterMultiplier();
			}
				
			tally += targetCell.piece().value()  * letterMult;
			letterCount++;
			row += rowOffset;
			col += colOffset;
			if (!board.validRowAndCol(row,col)) break;
			targetCell = ((ScrabbleBoard)board).scrabbleCell(row,col);

		}
		
		return letterCount> 1?tally*wordMultiplier:0;  // if less than 2 letters found - is not a word, return 0;
	
	}	
	

	public  boolean quit(){
		return choice.charAt(0) =='q';
	}
	
	public  boolean gameOver(){
		return gameOver;
	}

	
	public  void displayBoard(){
		for (int row = 0; row < ROWWIDTH;row++){
			for (int col = 0; col < COLWIDTH;col ++){
				out("|");
				out(((ScrabbleBoard)board).scrabbleCell(row,col).toString());
				out("|");
			}
			outln(" ");
		}
		outln(" "); 
		
	}	
	

	public  void setupPlayers(){
			player = new ScrabblePlayer();
			fillPlayersTray();
	}
	
	private  void fillPlayersTray() {
		 while (player.piecesRemaining() < MAXTRAYLETTERS && pieces.size() > 0){
				player.addPiece(retrievePiece());	
				word = player.piecesAsString();
			}
	}
	
		
	private  void displayPlayer(){
		outln("Player score = "+ player.score());
		outln("Player's Tray " + player.piecesAsString());
		
	}	

	
	public void createPieces(){
		addTilesToTileBag( createPiece("A",( (Integer)tileValueMap.get("A")).intValue(),9) );
		addTilesToTileBag( createPiece("B",( (Integer)tileValueMap.get("B")).intValue(),2) );
		addTilesToTileBag( createPiece("C",( (Integer)tileValueMap.get("C")).intValue(),2) );
		addTilesToTileBag( createPiece("D",( (Integer)tileValueMap.get("D")).intValue(),4) );
		addTilesToTileBag( createPiece("E",( (Integer)tileValueMap.get("E")).intValue(),12));
		addTilesToTileBag( createPiece("F",( (Integer)tileValueMap.get("F")).intValue(),2) );
		addTilesToTileBag( createPiece("G",( (Integer)tileValueMap.get("G")).intValue(),3) );
		addTilesToTileBag( createPiece("H",( (Integer)tileValueMap.get("H")).intValue(),2) );
		addTilesToTileBag( createPiece("I",( (Integer)tileValueMap.get("I")).intValue(),9) );
		addTilesToTileBag( createPiece("J",( (Integer)tileValueMap.get("J")).intValue(),1) );
		addTilesToTileBag( createPiece("K",( (Integer)tileValueMap.get("K")).intValue(),1) );
		addTilesToTileBag( createPiece("L",( (Integer)tileValueMap.get("L")).intValue(),4) );
		addTilesToTileBag( createPiece("M",( (Integer)tileValueMap.get("M")).intValue(),2) );
		addTilesToTileBag( createPiece("N",( (Integer)tileValueMap.get("N")).intValue(),6) );
		addTilesToTileBag( createPiece("O",( (Integer)tileValueMap.get("O")).intValue(),8) );
		addTilesToTileBag( createPiece("P",( (Integer)tileValueMap.get("P")).intValue(),2) );
		addTilesToTileBag( createPiece("Q",( (Integer)tileValueMap.get("Q")).intValue(),1) );
		addTilesToTileBag( createPiece("R",( (Integer)tileValueMap.get("R")).intValue(),6) );
		addTilesToTileBag( createPiece("S",( (Integer)tileValueMap.get("S")).intValue(),4) );
		addTilesToTileBag( createPiece("T",( (Integer)tileValueMap.get("T")).intValue(),6) );
		addTilesToTileBag( createPiece("U",( (Integer)tileValueMap.get("U")).intValue(),4) );
		addTilesToTileBag( createPiece("V",( (Integer)tileValueMap.get("V")).intValue(),2) );
		addTilesToTileBag( createPiece("W",( (Integer)tileValueMap.get("W")).intValue(),2) );
		addTilesToTileBag( createPiece("X",( (Integer)tileValueMap.get("X")).intValue(),1) );
		addTilesToTileBag( createPiece("Y",( (Integer)tileValueMap.get("Y")).intValue(),2) );
		addTilesToTileBag( createPiece("Z",( (Integer)tileValueMap.get("Z")).intValue(),1) );
		addTilesToTileBag( createPiece("b",( (Integer)tileValueMap.get("b")).intValue(),2) );
		
		
		
	}
	
	private void createTileValueMap(){
		tileValueMap.put("A",new  Integer(1));
		tileValueMap.put("B",new  Integer(3));
		tileValueMap.put("C",new  Integer(3));
		tileValueMap.put("D",new  Integer(2));
		tileValueMap.put("E",new  Integer(1));
		tileValueMap.put("F",new  Integer(4));
		tileValueMap.put("G",new  Integer(2));
		tileValueMap.put("H",new  Integer(4));
		tileValueMap.put("I",new  Integer(1));
		tileValueMap.put("J",new  Integer(8));
		tileValueMap.put("K",new  Integer(5));
		tileValueMap.put("L",new  Integer(1));
		tileValueMap.put("M",new  Integer(3));
		tileValueMap.put("N",new  Integer(1));
		tileValueMap.put("O",new  Integer(1));
		tileValueMap.put("P",new  Integer(3));
		tileValueMap.put("Q",new  Integer(10));
		tileValueMap.put("R",new  Integer(1));
		tileValueMap.put("S",new  Integer(1));
		tileValueMap.put("T",new  Integer(1));
		tileValueMap.put("U",new  Integer(1));
		tileValueMap.put("V",new  Integer(4));
		tileValueMap.put("W",new  Integer(4));
		tileValueMap.put("X",new  Integer(8));
		tileValueMap.put("Y",new  Integer(4));
		tileValueMap.put("Z",new  Integer(10));
		tileValueMap.put("b",new  Integer(0));

	}
		
		
	
	private List createPiece(String label, int val, int count){
		List tiles = new ArrayList();
		
		for (int i = 0; i<count; i++) {
			tiles.add(new Tile(val,label));
		}
		return tiles;
		
	}
	
			
	public GamePiece retrievePiece() {
		Tile tile = null;
		int nbr = 0;

		nbr = new Random().nextInt(pieces.size()-1);
		tile = (Tile)pieces.get(nbr);
		pieces.remove(tile);

		outln("Pieces left = " + pieces.size());
		return tile;
	}
	
	public Player winningPlayer(){
			return null;
	}
	
	public void addTilesToTileBag(List tiles){
		Iterator iter = tiles.iterator();
		while (iter.hasNext()){
			pieces.add((Tile)iter.next());
		}
	}

}

