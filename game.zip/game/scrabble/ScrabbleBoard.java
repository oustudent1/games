package game.scrabble;

import game.Abstract2DGridGameContext;
import game.Coordinate;

/**
 * @author joe

 */
public class ScrabbleBoard extends Abstract2DGridGameContext {


	//private ScrabbleCell[][] cells;
	public ScrabbleBoard() {
		super();
	}
	
	public ScrabbleBoard(int rows, int cols) {
		super(rows,cols);
		cells = new ScrabbleCell[rows][cols];
		init();
	}
	
	public void init(){
		super.init();
		setCellMultipliers();
	}
	
	
			
	public void createCells(){
		for (int i = 0; i<cells.length; i++){
			for (int j = 0; j < cells[i].length; j++){
				cells[i][j] = new ScrabbleCell();
			}
		}
	}
	
	
	public ScrabbleCell scrabbleCell(Coordinate coord){
			return (ScrabbleCell)super.cells[coord.x()][coord.y()];
	}
	
	public ScrabbleCell scrabbleCell(int x, int y){
			return (ScrabbleCell)super.cells[x][y];
	}
	
	private  void setCellMultipliers(){
		// tw
		((ScrabbleCell)cells[0][0]).multiplier(3,3);
		((ScrabbleCell)cells[0][7]).multiplier(3,3);		
		((ScrabbleCell)cells[0][14]).multiplier(3,3);
		
		((ScrabbleCell)cells[7][0]).multiplier(3,3);
		((ScrabbleCell)cells[7][14]).multiplier(3,3);
		
		((ScrabbleCell)cells[14][0]).multiplier(3,3);
		((ScrabbleCell)cells[14][7]).multiplier(3,3);		
		((ScrabbleCell)cells[14][14]).multiplier(3,3);
		
		//tw
		((ScrabbleCell)cells[5][1]).multiplier(3,2);
		((ScrabbleCell)cells[1][9]).multiplier(3,2);
		
		((ScrabbleCell)cells[1][5]).multiplier(3,2);
		((ScrabbleCell)cells[5][5]).multiplier(3,2);
		((ScrabbleCell)cells[5][9]).multiplier(3,2);
		((ScrabbleCell)cells[5][13]).multiplier(3,2);
		
		((ScrabbleCell)cells[9][1]).multiplier(3,2);
		((ScrabbleCell)cells[9][5]).multiplier(3,2);
		((ScrabbleCell)cells[9][9]).multiplier(3,2);
		((ScrabbleCell)cells[9][13]).multiplier(3,2);
		
		((ScrabbleCell)cells[13][5]).multiplier(3,2);
		((ScrabbleCell)cells[13][9]).multiplier(3,2);
		
		// dl
		((ScrabbleCell)cells[0][3]).multiplier(2,2);
		((ScrabbleCell)cells[0][11]).multiplier(2,2);
		
		((ScrabbleCell)cells[2][6]).multiplier(2,2);
		((ScrabbleCell)cells[2][8]).multiplier(2,2);
		
		((ScrabbleCell)cells[3][0]).multiplier(2,2);
		((ScrabbleCell)cells[3][7]).multiplier(2,2);
		((ScrabbleCell)cells[3][14]).multiplier(2,2);
		
		((ScrabbleCell)cells[6][2]).multiplier(2,2);
		((ScrabbleCell)cells[6][6]).multiplier(2,2);
		((ScrabbleCell)cells[6][8]).multiplier(2,2);
		((ScrabbleCell)cells[6][12]).multiplier(2,2);
		((ScrabbleCell)cells[7][3]).multiplier(2,2);
		((ScrabbleCell)cells[7][11]).multiplier(2,2);
		
		((ScrabbleCell)cells[8][2]).multiplier(2,2);
		((ScrabbleCell)cells[8][6]).multiplier(2,2);
		((ScrabbleCell)cells[8][8]).multiplier(2,2);
		((ScrabbleCell)cells[8][12]).multiplier(2,2);
		
		((ScrabbleCell)cells[11][0]).multiplier(2,2);
		((ScrabbleCell)cells[11][7]).multiplier(2,2);
		((ScrabbleCell)cells[11][14]).multiplier(2,2);
		
		((ScrabbleCell)cells[12][6]).multiplier(2,2);
		((ScrabbleCell)cells[12][8]).multiplier(2,2);
		
		((ScrabbleCell)cells[14][3]).multiplier(2,2);
		((ScrabbleCell)cells[14][11]).multiplier(2,2);
		
		// dw
		
		((ScrabbleCell)cells[1][1]).multiplier(2,3);
		((ScrabbleCell)cells[1][13]).multiplier(2,3);
		
		((ScrabbleCell)cells[2][2]).multiplier(2,3);
		((ScrabbleCell)cells[2][12]).multiplier(2,3);
		
		((ScrabbleCell)cells[3][3]).multiplier(2,3);
		((ScrabbleCell)cells[3][11]).multiplier(2,3);
		
		((ScrabbleCell)cells[4][4]).multiplier(2,3);
		((ScrabbleCell)cells[4][10]).multiplier(2,3);
		
		((ScrabbleCell)cells[7][7]).multiplier(2,3);
		
		((ScrabbleCell)cells[13][1]).multiplier(2,3);
		((ScrabbleCell)cells[13][13]).multiplier(2,3);
		
		((ScrabbleCell)cells[12][2]).multiplier(2,3);
		((ScrabbleCell)cells[12][12]).multiplier(2,3);
		
		((ScrabbleCell)cells[11][3]).multiplier(2,3);
		((ScrabbleCell)cells[11][11]).multiplier(2,3);
		
		((ScrabbleCell)cells[10][4]).multiplier(2,3);
		((ScrabbleCell)cells[10][10]).multiplier(2,3);
		
	}

}
